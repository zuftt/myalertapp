import {
  View,
  Text,
  Image,
  ImageBackground,
  Pressable,
  TouchableOpacity,
  Alert,
  TextInput,
} from "react-native";
import React, { useState } from "react";
import Colors from "./../../constants/Colors";
import * as WebBrowser from "expo-web-browser";
import { useRouter } from "expo-router";
import * as Notifications from "expo-notifications";

export const useWarmUpBrowser = () => {
  React.useEffect(() => {
    void WebBrowser.warmUpAsync();
    return () => {
      void WebBrowser.coolDownAsync();
    };
  }, []);
};

WebBrowser.maybeCompleteAuthSession();

export default function LogInScreen() {
  useWarmUpBrowser();
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  // Request notification permissions
  const requestNotificationPermission = async () => {
    const { status: existingStatus } =
      await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;

    if (existingStatus !== "granted") {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }

    if (finalStatus !== "granted") {
      Alert.alert(
        "Permission required",
        "Please enable notifications to stay updated."
      );
      return false;
    }

    console.log("Notification permission granted");
    return true;
  };

  const handleSignIn = async () => {
    if (!email || !password) {
      Alert.alert("Error", "Please enter both email and password.");
      return;
    }

    try {
      // Simulated authentication logic
      if (email === "user@example.com" && password === "password123") {
        Alert.alert("Success", "Logged in successfully.");

        const notificationGranted = await requestNotificationPermission();
        if (notificationGranted) {
          console.log("Notifications enabled successfully!");
        }

        router.push("/(tabs)/home"); // Navigate to the home screen
      } else {
        Alert.alert("Error", "Invalid email or password.");
      }
    } catch (err) {
      console.error("Authentication error", err);
      Alert.alert("Error", "An error occurred. Please try again.");
    }
  };

  const onAdminPress = () => {
    router.push("/admin");
  };

  return (
    <ImageBackground
      source={require("./../../assets/images/background.jpg")}
      style={{
        flex: 1,
        justifyContent: "flex-start",
      }}
      resizeMode="cover"
    >
      <View
        style={{
          paddingTop: 120,
          alignItems: "center",
        }}
      >
        <Image
          source={require("./../../assets/images/login.png")}
          style={{
            width: "80%",
            height: 300,
            alignSelf: "center",
          }}
        />
        <Text
          style={{
            fontFamily: "outfit-bold",
            fontSize: 30,
            textAlign: "center",
            color: "#ffffff",
            marginTop: 20,
          }}
        >
          Your safety is our priority
        </Text>
        <Text
          style={{
            fontFamily: "outfit",
            fontSize: 15,
            textAlign: "center",
            color: "#ffffff",
            marginTop: 20,
          }}
        >
          Let’s help build a safer community
        </Text>

        {/* Email Input */}
        <TextInput
          placeholder="Email"
          placeholderTextColor="#ccc"
          style={{
            width: "80%",
            height: 50,
            backgroundColor: "#fff",
            borderRadius: 8,
            paddingHorizontal: 10,
            marginTop: 20,
            fontFamily: "outfit",
          }}
          keyboardType="email-address"
          autoCapitalize="none"
          value={email}
          onChangeText={setEmail}
        />

        {/* Password Input */}
        <TextInput
          placeholder="Password"
          placeholderTextColor="#ccc"
          style={{
            width: "80%",
            height: 50,
            backgroundColor: "#fff",
            borderRadius: 8,
            paddingHorizontal: 10,
            marginTop: 15,
            fontFamily: "outfit",
          }}
          secureTextEntry
          value={password}
          onChangeText={setPassword}
        />

        {/* Login Button */}
        <Pressable
          onPress={handleSignIn}
          style={{
            padding: 15,
            marginTop: 40,
            backgroundColor: "#ff8c00",
            width: "80%",
            borderRadius: 14,
            alignItems: "center",
            justifyContent: "center",
            shadowColor: "#000",
            shadowOffset: { width: 0, height: 4 },
            shadowOpacity: 0.1,
            shadowRadius: 6,
            elevation: 5,
          }}
        >
          <Text
            style={{
              fontFamily: "outfit-bold",
              fontSize: 22,
              textAlign: "center",
              color: "#ffffff",
            }}
          >
            Log In
          </Text>
        </Pressable>

        {/* Admin Button */}
        <TouchableOpacity onPress={onAdminPress}>
          <Text
            style={{
              fontFamily: "outfit",
              fontSize: 14,
              textAlign: "center",
              color: "#ffffff",
              textDecorationLine: "underline",
              marginTop: 30,
            }}
          >
            Admin
          </Text>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
}
